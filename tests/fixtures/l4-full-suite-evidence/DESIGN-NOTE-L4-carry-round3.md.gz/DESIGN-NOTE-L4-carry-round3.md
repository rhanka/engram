# Design note: L4 carry onto 0.21.3, round 3 (2026-10-28)

Owner rule: round 2 repeated both round-1 defect classes, so this note comes before round 3. Round 3 is the last Muse round. If it fails, Sol becomes the author for 2 rounds and Opus reviews; after that, options go to the owner.
Inputs: L4-carry-review-sol.out (r1), L4-carry-review-sol-r2.out (r2), SUITE-COMPARISON-METHOD.md.

## Class A — disabled-install detector proves a declaration, not an execution (MAJOR 1, two rounds)
Root cause: both paths (npm log and preload trace) classify text that NAMES a build (`node-gyp`, `prebuild-install || node-gyp rebuild`) as a build. npm echoes the full lifecycle script before running it, and the preload marks `sh -c "<script>"` before either branch runs.
Required method:
1. Logs are never proof of execution. Remove every log-text predicate from the failure decision (keep log excerpts as diagnostics only).
2. Execution proof comes only from (a) a traced spawn whose executable basename is `node-gyp`, `make`, `cc`, `c++`, `g++`, `gcc` or `clang*`, attributed to the cwd of `better-sqlite3` or `fs-ext` (the memory native modules), or (b) a filesystem observable in that module after install: `build/config.gypi` or `build/Release/obj.target/` exists (source-build outputs; a prebuilt download yields only `build/Release/*.node`). A `sh -c` dispatch and a `prebuild-install` spawn are NOT build proof.
3. The gate fails iff (a) or (b) holds for a memory native module. Third-party addons (tree-sitter-*) are out of scope, as in round 2.
4. Regressions, all in memory: negatives = lifecycle banner `> prebuild-install || node-gyp rebuild --release` + `prebuild-install info install Successfully installed prebuilt binary!`; the `npm info run` echo; the round-1 tree-sitter warning; the preload classification of a successful prebuild (`sh -c` dispatch + `prebuild-install` spawn only); a prebuilt-only filesystem layout. Positives = executed `node-gyp` spawn for each of better-sqlite3 and fs-ext; `obj.target` present for each. Keep the nine round-2 cases. Show the tests bite: old predicate and no-op detector each fail named cases.

## Class B — comparison evidence not reproducible from the commit (MAJOR 2, two rounds)
Root cause: reports, logs and comparator stayed in an ignored scratch directory; the committed summary pointed at them.
Required method:
1. Disk is now above the 15 G floor (29 G): re-run both sides fresh under SUITE-COMPARISON-METHOD.md (`.baseline` worktree at 8b93ba6b sharing the branch installation, identical builds/env/cache).
2. Comparator: port the reviewed comparator of the OpenERP lot (branch feat/ontology-guardian-openerp, tests/compare-openerp-full-suite.mjs: classifyDiagnostic, failureRecords keyed by file + fullName + kind + occurrence, compareReports on identity + category + modules + normalized cause; reviewed SOLID by Muse Wonder) as tests/compare-l4-full-suite.mjs, with its self-test fixtures plus the r2 MINOR cases (unequal multiplicity, mixed duplicate statuses, changed diagnostics). Do not invent a new comparator.
3. Commit in a tracked evidence location (as the OpenERP lot did): gzip-compressed vitest JSON reports of both sides, setup/build logs, the comparator and its output, each with raw and compressed sha256 and byte counts referenced from candidate-validation-carry-0213.json. No pointer to an ignored path.
4. Conductor decision on baseline-only failures: a failure present ONLY on the baseline does not block the branch, provided the comparison lists it with its original status and diagnostic, category `unclassified`, and states it as unresolved. No root-cause claim (no "host load") unless demonstrated by a retained diagnostic. Any branch-side added failure/skip, or any branch-side `unclassified` / `build-prerequisite` failure, fails the comparison.
5. The historical candidate-validation.json stays unchanged.

## MINORs (conductor decides: fix both in round 3)
- Comparator multiplicity/cause handling: closed by Class B step 2.
- P3 typo: candidate-validation-carry-0213.json repack.p3 must be the 64-char 1c96bada2a749155f29aae763fa73ea6379c385d619f70614110f59b6b10b730, as a structured digest field checked against the frozen manifest.

## Unchanged
Tarball 965c93e3… (no repack unless a packed file changes; if one does, STOP and report), P3, contract digest dd0cccbd, intentHash carriage, rebase fidelity. No scope growth.

## Addendum E1 — conductor exception to SUITE-COMPARISON-METHOD step 1 (2026-10-29)
Context: the round-3 author (Sol, Muse unavailable on billing) stopped at method step 1 because the root lockfiles differ (`lockfile-stop.log`, commit 876bbf3b).
Decision (conductor; the method is conductor-owned, no contract or owner scope involved):
1. The root package-lock.json delta between 8b93ba6b and the branch (version 0.22.0, optional MCP peers, SDK 1.32.2/1.29.0 + hono; `lock-delta.log`) is the lot's legitimate content. engram-memory/package-lock.json, which carries the native addons, is identical. Comparing with the baseline running on the branch installation (dependency superset) is accepted as the controlled setup for this lot.
2. The committed R2 historical reports (r2-historical-*-vitest.json.gz, same shared native installation, same builds/env/cache), compared with the ported occurrence-level comparator, are accepted as the full-suite evidence. A fresh re-run is waived (host disk near the floor; it would reproduce the same setup).
3. Baseline-only failures stay as recorded: unclassified, original diagnostics, unresolved, no root-cause claim (step 4 of this note). Any branch-side added failure/skip or branch-side unclassified failure would still fail the comparison.
The candidate-validation evidence must state that it relies on this exception (E1), with this note's path.
